package com.adt.AWeb.ui.activity;

import android.os.Bundle;
import com.adt.AWeb.R;
import com.adt.AWeb.common.activity.BaseActivity;

public class MainActivity extends BaseActivity { 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
    }

}